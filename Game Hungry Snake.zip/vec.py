import math

v = [1, 2]    # vector2
v = [1, 2, 3] # vector3

def add(u, v):    
    return [a + b for a, b in zip(u, v)]

u = [1, 2]
v = [3, 4]
add(u, v) #gives [4, 6]